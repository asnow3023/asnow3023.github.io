$(document).ready(function() {
    $("#slider").bxSlider({
        autoStart: true,
        auto: true,
        minSlides: 1,
        maxSlides: 1,
        slideWidth: 1000,
        slideMargin: 20,
        randomStart: true,
        autoDelay: 3000,
    });
});