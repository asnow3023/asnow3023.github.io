$(document).ready(function () {
    var current = document.getElementById("navMenu");
    current.classList.remove("active");

    $("#navMenu a").each(function () {
      console.log($(this).prop("href"));
      });
});